const express = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');

require('dotenv').config();

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('public')); // Serve static files

// Set up Multer for handling file uploads
const upload = multer({
    dest: 'uploads/', // Directory where the uploaded files will be stored
});

// Handle form submission with file upload
app.post('/upload', upload.array('productImages'), (req, res) => {
    try {
        // Log the received form data
        console.log('Received form submission:', req.body);
        
        // Log the received files
        console.log('Received files:', req.files);
        
        // Here you can process the files or return the file URLs
        const uploadedImages = req.files.map(file => {
            return `http://127.0.0.1:3000/uploads/${file.filename}`; // Example: URL to access the uploaded file
        });

        // Return success response
        res.json({
            success: true,
            images: uploadedImages,
        });
    } catch (error) {
        console.error('Error uploading files:', error);
        res.status(500).json({ success: false, message: 'Error uploading files' });
    }
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
